#!/bin/bash

dnf install -y yandex-browser-stable-22.7.5.933-1.x86_64.rpm